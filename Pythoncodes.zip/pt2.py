from tensorflow import keras
from keras.utils import normalize
from keras.optimizers import SGD
from keras.metrics import Precision
import numpy as np
from tensorflow.keras import layers
from keras.models import Sequential
from keras.layers import Dense

noise_factor = 0.24
(x_train, y_train), (x_test, y_test) = keras.datasets.mnist.load_data()
x_train = x_train.reshape(-1, 784).astype("float32")
x_test = x_test.reshape(-1, 784).astype("float32")
x_train_noisy = x_train + noise_factor * np.random.normal(loc=0.0 , scale = 1.0, size = x_train.shape)
x_test_noisy = x_test + noise_factor * np.random.normal(loc=0.0 , scale = 1.0, size = x_test.shape)
x_train_noisy = np.clip(x_train_noisy , 0. , 1.)
x_test_noisy = np.clip(x_test_noisy , 0. , 1.)
x_train1 = normalize(x_train,axis=-1, order=2)
x_test1 = normalize(x_test,axis=-1, order=2)
y_train = keras.utils.to_categorical(y_train, 10)
y_test = keras.utils.to_categorical(y_test, 10)

m = Sequential()
m.add(Dense(40, input_dim=784, activation='sigmoid'))
m.add(Dense(10, activation='sigmoid'))
m.compile(loss='binary_crossentropy', optimizer=SGD(learning_rate=0.0001), metrics=['accuracy'])
m.fit(x_train1, y_train, epochs=10, batch_size=20)
accuracy = m.evaluate(x_test1, y_test)
print(accuracy)
