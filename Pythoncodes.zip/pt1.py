from keras.models import Sequential
from keras.layers import Dense
from keras.utils import normalize
from tensorflow import keras
from keras.optimizers import SGD
from tensorflow.keras import layers
from keras.metrics import Precision

(x_train, y_train), (x_test, y_test) = keras.datasets.mnist.load_data()
x_train = x_train.reshape(-1, 784).astype("float32")
x_test = x_test.reshape(-1, 784).astype("float32")
x_train1 = normalize(x_train,axis=-1, order=2)
x_test1 = normalize(x_test,axis=-1, order=2)
y_train = keras.utils.to_categorical(y_train, 10)
y_test = keras.utils.to_categorical(y_test, 10)
m = Sequential()
m.add(Dense(40, input_dim=784, activation='sigmoid'))
m.add(Dense(10, activation='sigmoid'))
m.compile(loss='binary_crossentropy', optimizer=SGD(learning_rate=0.0001), metrics=['accuracy'])
m.fit(x_train1, y_train, epochs=10, batch_size=10)
accuracy = m.evaluate(x_test1, y_test)
print(accuracy)
